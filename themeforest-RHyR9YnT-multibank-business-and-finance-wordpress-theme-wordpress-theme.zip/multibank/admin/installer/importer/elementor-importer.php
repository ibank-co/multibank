<?php
namespace MultibankSpace\Admin\Installer\Importer;

use MultibankSpace\Admin\Installer\Importer\Elementor_Attachments;
use MultibankSpace\Admin\Installer\Importer\Elementor_Templates;
use MultibankSpace\Admin\Installer\Importer\Elementor_Widgets;
use MultibankSpace\Core\Utils\API_Requests;
use MultibankSpace\Core\Utils\Utils;

use Elementor\Plugin as Elementor_Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Importer handler class is responsible for different methods on importing "Elementor" plugin elements.
 *
 * @since 1.0.4
 */
class Elementor_Importer {

	/**
	 * Elementor Templates Import constructor.
	 *
	 * @since 1.0.4
	 */
	public function __construct() {
		if ( ! self::activation_status() || ! API_Requests::check_token_status() ) {
			return;
		}

		add_action( 'import_end', array( $this, 'end_import' ) );
	}

	/**
	 * Activation status.
	 *
	 * @since 1.0.4
	 *
	 * @return bool Activation status.
	 */
	public static function activation_status() {
		return ( did_action( 'elementor/loaded' ) && class_exists( 'Cmsmasters_Elementor_Addon' ) );
	}

	/**
	 * End import.
	 *
	 * Fires on import_end action.
	 *
	 * @since 1.0.4
	 */
	public function end_import() {
		$demo = Utils::get_demo();

		$displayed_ids = get_transient( "cmsmasters_multibank_{$demo}_import_displayed_ids" );

		if ( false === $displayed_ids ) {
			$displayed_ids = array();
		}

		do_action( 'cmsmasters_replace_elementor_locations_id', $displayed_ids );

		$this->change_import_elements_ids();

		delete_transient( "cmsmasters_multibank_{$demo}_elementor_import_templates_ids" );

		set_transient( "cmsmasters_multibank_{$demo}_content_import_status", 'imported', HOUR_IN_SECONDS );
	}

	/**
	 * Change elements ids on import.
	 *
	 * @since 1.0.4
	 */
	protected function change_import_elements_ids() {
		$post_ids = Utils::get_elementor_post_ids();

		if ( empty( $post_ids ) ) {
			return;
		}

		$demo = Utils::get_demo();

		$templates_ids = get_transient( "cmsmasters_multibank_{$demo}_elementor_import_templates_ids" );
		$attachments_ids = get_transient( "cmsmasters_multibank_{$demo}_import_attachments_ids" );
		$displayed_ids = get_transient( "cmsmasters_multibank_{$demo}_import_displayed_ids" );

		if ( empty( $templates_ids ) && empty( $attachments_ids ) && empty( $displayed_ids ) ) {
			return;
		}

		foreach ( $post_ids as $post_id ) {
			$document = Elementor_Plugin::$instance->documents->get( $post_id );

			if ( $document ) {
				$data = $document->get_elements_data();
			}

			if ( empty( $data ) ) {
				continue;
			}

			$data = Elementor_Plugin::$instance->db->iterate_data( $data, function( $element ) use ( $templates_ids, $attachments_ids, $displayed_ids, $post_id ) {
				$element = Elementor_Templates::change_import_templates_ids( $element, $templates_ids );

				if (
					'elementor_library' !== get_post_type( $post_id ) &&
					'revision' !== get_post_type( $post_id )
				) {
					$element = Elementor_Attachments::change_import_attachments_ids( $element, $attachments_ids );
				}

				$element = Elementor_Widgets::change_import_displayed_ids( $element, $displayed_ids );

				return $element;
			} );

			$document->save( array(
				'elements' => $data,
			) );
		}
	}

}
