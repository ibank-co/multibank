<?php
namespace MultibankSpace\Admin\Installer\Importer;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Elementor Widgets handler class is responsible for different methods on importing "Elementor" plugin widgets with controls where need to replace ids.
 *
 * @since 1.0.0
 * @since 1.0.4 Importer optimization.
 */
class Elementor_Widgets {

	/**
	 * Change widgets query control in posts with _elementor_data on import.
	 *
	 * @since 1.0.4
	 *
	 * @param array $element Elementor element.
	 * @param array $displayed_ids Displayed ids.
	 *
	 * @return array Elementor element.
	 */
	public static function change_import_displayed_ids( $element, $displayed_ids = array() ) {
		if ( empty( $element['widgetType'] ) ) {
			return $element;
		}

		$element = self::parse_query_widgets( $element, $displayed_ids );
		$element = self::parse_nav_menu_widget( $element, $displayed_ids );

		return $element;
	}

	/**
	 * Parse query widgets.
	 *
	 * @since 1.0.0
	 * @since 1.0.4 Change method visibility and declare it as static.
	 *
	 * @param array $element Elementor element.
	 * @param array $displayed_ids Displayed ids.
	 *
	 * @return array Elementor element.
	 */
	private static function parse_query_widgets( $element, $displayed_ids = array() ) {
		$blog_widgets = array(
			'cmsmasters-blog-grid',
			'cmsmasters-blog-slider',
			'cmsmasters-blog-featured',
			'cmsmasters-ticker',
		);

		$all_widgets = $blog_widgets;
		$all_widgets[] = 'cmsmasters-woo-products';

		if ( ! in_array( $element['widgetType'], $all_widgets, true ) ) {
			return $element;
		}
		
		$displayed_post_ids = ( isset( $displayed_ids['post_id'] ) ? $displayed_ids['post_id'] : array() );
		$displayed_taxonomy_ids = ( isset( $displayed_ids['taxonomy'] ) ? $displayed_ids['taxonomy'] : array() );

		$post_ids = self::rearrange_displayed_ids( $displayed_post_ids );
		$term_ids = self::rearrange_displayed_ids( $displayed_taxonomy_ids );

		$setting_prefix = 'query_';

		if ( in_array( $element['widgetType'], $blog_widgets, true ) ) {
			$setting_prefix = 'blog_';
		}

		$widget_fields = array(
			'posts_in' => 'post',
			'include_term_ids' => 'term',
			'filter_' . $setting_prefix . 'include_term_ids' => 'term',
			'exclude_term_ids' => 'term',
			'posts_not_in' => 'post',
			'selected_authors' => 'author',
			'fallback_posts_in' => 'post',
		);

		foreach ( $widget_fields as $field_key => $ids_type ) {
			switch( $ids_type ) {
				case 'post':
					$replace_ids = $post_ids;

					break;
				case 'term':
					$replace_ids = $term_ids;

					break;
			}

			$setting_key = $setting_prefix . $field_key;

			if ( 'filter_' . $setting_prefix . 'include_term_ids' === $field_key ) {
				$setting_key = $field_key;
			}

			if (
				! isset( $element['settings'][ $setting_key ] ) ||
				empty( $element['settings'][ $setting_key ] )
			) {
				continue;
			}

			if ( 'author' === $ids_type ) {
				$element['settings'][ $setting_key ] = array();

				continue;
			}

			$element['settings'][ $setting_key ] = self::replace_widget_field_ids(
				$element['settings'][ $setting_key ],
				$replace_ids
			);
		}

		return $element;
	}

	/**
	 * Parse navigation menu widget.
	 *
	 * @since 1.0.0
	 * @since 1.0.4 Change method visibility and declare it as static.
	 *
	 * @param array $element Elementor element.
	 * @param array $displayed_ids Displayed ids.
	 *
	 * @return array Elementor element.
	 */
	private static function parse_nav_menu_widget( $element, $displayed_ids = array() ) {
		if (
			'cmsmasters-nav-menu' !== $element['widgetType'] ||
			! isset( $displayed_ids['taxonomy']['nav_menu'] ) ||
			empty( $displayed_ids['taxonomy']['nav_menu'] ) ||
			empty( $element['settings']['nav_menu'] )
		) {
			return $element;
		}

		$old_id = $element['settings']['nav_menu'];

		if ( isset( $displayed_ids['taxonomy']['nav_menu'][ $old_id ] ) ) {
			$element['settings']['nav_menu'] = strval( $displayed_ids['taxonomy']['nav_menu'][ $old_id ] );
		}

		return $element;
	}

	/**
	 * Rearrange displayed ids.
	 *
	 * @since 1.0.0
	 * @since 1.0.4 Change method visibility and declare it as static.
	 *
	 * @param array $displayed_ids Displayed ids.
	 *
	 * @return array Displayed ids.
	 */
	private static function rearrange_displayed_ids( $displayed_ids ) {
		$out_ids = array();

		foreach ( $displayed_ids as $ids ) {
			foreach ( $ids as $old_id => $new_id ) {
				$out_ids[ $old_id ] = $new_id;
			}
		}

		return $out_ids;
	}

	/**
	 * Replace widget field ids.
	 *
	 * @since 1.0.0
	 * @since 1.0.4 Change method visibility and declare it as static.
	 *
	 * @param array $field_ids Field ids.
	 * @param array $replace_ids Replace ids.
	 *
	 * @return array ids.
	 */
	private static function replace_widget_field_ids( $field_ids, $replace_ids ) {
		$final_ids = array();

		foreach ( $field_ids as $index => $old_id ) {
			if ( isset( $replace_ids[ $old_id ] ) ) {
				$final_ids[ $index ] = strval( $replace_ids[ $old_id ] );
			}
		}

		return $final_ids;
	}

}
