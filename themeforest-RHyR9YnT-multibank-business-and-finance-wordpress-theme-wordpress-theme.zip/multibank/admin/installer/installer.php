<?php
namespace MultibankSpace\Admin\Installer;

use MultibankSpace\Admin\Installer\Merlin\Config;
use MultibankSpace\Admin\Installer\Merlin\Filters;
use MultibankSpace\Admin\Installer\Importer\Importer;
use MultibankSpace\Admin\Installer\Plugin_Activator\Plugin_Activator;
use MultibankSpace\Core\Utils\API_Requests;
use MultibankSpace\Core\Utils\File_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Installer module.
 *
 * Main class for installer module.
 *
 * @since 1.0.0
 */
class Installer {

	/**
	 * Installer module constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'after_switch_theme', array( $this, 'after_switch_theme_actions' ) );

		$this->set_first_theme_version();

		new Plugin_Activator();

		new Importer();

		$this->run_wizard();
	}

	/**
	 * Set first theme version.
	 *
	 * @since 1.0.0
	 */
	private function set_first_theme_version() {
		if ( get_option( 'cmsmasters_multibank_version', false ) ) {
			return;
		}

		update_option( 'cmsmasters_multibank_version', '1.0.0' );
	}

	/**
	 * Actions on after switch theme.
	 *
	 * @since 1.0.0
	 */
	public function after_switch_theme_actions() {
		$this->set_token();

		$this->set_settings();

		$this->first_setup();
	}

	/**
	 * Set token if theme has been activated earlier.
	 *
	 * @since 1.0.0
	 */
	public function set_token() {
		API_Requests::regenerate_token();
	}

	/**
	 * Set settings.
	 *
	 * @since 1.0.0
	 * @since 1.0.3 Fixed import templates for elementor.
	 */
	public function set_settings() {
		update_option( 'default_pingback_flag', 0 );

		update_option( 'elementor_page_title_selector', '.cmsmasters-headline' );
		update_option( 'elementor_disable_color_schemes', 'yes' );
		update_option( 'elementor_disable_typography_schemes', 'yes' );
		update_option( 'elementor_unfiltered_files_upload', 1 );
	}

	/**
	 * First setup actions.
	 *
	 * @since 1.0.0
	 */
	private function first_setup() {
		if ( 'pending' !== get_option( 'cmsmasters_multibank_first_setup', 'pending' ) ) {
			return;
		}

		$this->set_defaults();

		do_action( 'cmsmasters_set_backup_options', true );

		do_action( 'cmsmasters_set_import_status', 'pending' );

		update_option( 'cmsmasters_multibank_first_setup', 'done' );
	}

	/**
	 * Set defaults.
	 *
	 * @since 1.0.0
	 */
	private function set_defaults() {
		$kits_path = get_parent_theme_file_path( '/theme-config/defaults/default-kits.json' );
		$options_path = get_parent_theme_file_path( '/theme-config/defaults/default-theme-options.json' );

		$kits = File_Manager::get_file_contents( $kits_path );
		$options = File_Manager::get_file_contents( $options_path );

		if ( '' !== $kits ) {
			$kits = json_decode( $kits, true );

			update_option( 'cmsmasters_multibank_default_kits', $kits );
		}

		if ( '' !== $options ) {
			$options = json_decode( $options, true );

			update_option( 'cmsmasters_multibank_options', $options );
		}
	}

	/**
	 * Require Merlin Installer.
	 *
	 * @since 1.0.0
	 */
	private function run_wizard() {
		require_once get_parent_theme_file_path( '/admin/installer/merlin/vendor/autoload.php' );
		require_once get_parent_theme_file_path( '/admin/installer/merlin/class-merlin.php' );

		$config = array(
			'directory' => 'admin/installer/merlin', // Location / directory where Merlin WP is placed in your theme.
			'merlin_url' => 'merlin', // The wp-admin page slug where Merlin WP loads.
			'parent_slug' => 'themes.php', // The wp-admin parent page slug for the admin menu item.
			'capability' => 'manage_options', // The capability required for this menu to be displayed to the user.
			'child_action_btn_url' => 'https://developer.wordpress.org/themes/advanced-topics/child-themes/', // URL for the 'child-action-link'.
			'dev_mode' => false, // Enable development mode for testing.
			'license_step' => true, // EDD license activation step.
			'license_required' => true, // Require the license activation step.
			'license_help_url' => 'https://docs.cmsmasters.net/blog/how-to-find-your-envato-purchase-code/', // URL for the 'license-tooltip'.
			'edd_remote_api_url' => '', // EDD_Theme_Updater_Admin remote_api_url.
			'edd_item_name' => '', // EDD_Theme_Updater_Admin item_name.
			'edd_theme_slug' => '', // EDD_Theme_Updater_Admin item_slug.
			'ready_big_button_url' => home_url( '/' ), // Link for the big button on the ready step.
		);

		$strings = array(
			'admin-menu' => esc_html__( 'Theme Setup', 'multibank' ),
			/* translators: 1: Title Tag 2: Theme Name 3: Closing Title Tag */
			'title%s%s%s%s' => esc_html__( '%1$s%2$s Themes &lsaquo; Theme Setup: %3$s%4$s', 'multibank' ),
			'return-to-dashboard' => esc_html__( 'Return to the dashboard', 'multibank' ),
			'ignore' => '',

			'btn-skip' => esc_html__( 'Skip', 'multibank' ),
			'btn-next' => esc_html__( 'Next', 'multibank' ),
			'btn-start' => esc_html__( 'Start', 'multibank' ),
			'btn-no' => esc_html__( 'Cancel', 'multibank' ),
			'btn-plugins-install' => esc_html__( 'Install', 'multibank' ),
			'btn-child-install' => esc_html__( 'Install', 'multibank' ),
			'btn-content-install' => esc_html__( 'Install', 'multibank' ),
			'btn-import' => esc_html__( 'Import', 'multibank' ),
			'btn-license-activate' => esc_html__( 'Activate', 'multibank' ),
			'btn-license-skip' => esc_html__( 'Later', 'multibank' ),

			/* translators: Theme Name */
			'license-header%s' => esc_html__( 'Activate %s', 'multibank' ),
			/* translators: Theme Name */
			'license-header-success%s' => esc_html__( '%s license is Activated', 'multibank' ),
			/* translators: Theme Name */
			'license%s' => esc_html__( 'Enter your license key to enable remote updates and theme support.', 'multibank' ),
			'license-label' => esc_html__( 'License key', 'multibank' ),
			'license-success%s' => esc_html__( 'The theme is already registered, so you can go to the next step!', 'multibank' ),
			'license-json-success%s' => esc_html__( 'Your license is activated! Remote updates and theme support are enabled.', 'multibank' ),
			'license-tooltip' => esc_html__( 'Need help?', 'multibank' ),

			/* translators: Theme Name */
			'welcome-header%s' => esc_html__( 'Welcome to %s', 'multibank' ),
			'welcome-header-success%s' => esc_html__( 'Hi. Welcome back', 'multibank' ),
			'welcome%s' => esc_html__( 'This wizard will set up your theme, install plugins, and import content. It is optional & should take only a few minutes.', 'multibank' ),
			'welcome-success%s' => esc_html__( 'You may have already run this theme setup wizard. If you would like to proceed anyway, click on the "Start" button below.', 'multibank' ),

			'child-header' => esc_html__( 'Install Child Theme', 'multibank' ),
			'child-header-success' => esc_html__( 'You\'re good to go!', 'multibank' ),
			'child' => esc_html__( 'Let\'s build & activate a child theme so you may easily make theme changes.', 'multibank' ),
			'child-success%s' => esc_html__( 'Your child theme has already been installed and is now activated, if it wasn\'t already.', 'multibank' ),
			'child-action-link' => esc_html__( 'Learn about child themes', 'multibank' ),
			'child-json-success%s' => esc_html__( 'Awesome. Your child theme has already been installed and is now activated.', 'multibank' ),
			'child-json-already%s' => esc_html__( 'Awesome. Your child theme has been created and is now activated.', 'multibank' ),

			'plugins-header' => esc_html__( 'Install Plugins', 'multibank' ),
			'plugins-header-success' => esc_html__( 'You\'re up to speed!', 'multibank' ),
			'plugins' => esc_html__( 'Let\'s install some essential WordPress plugins to get your site up to speed.', 'multibank' ),
			'plugins-success%s' => esc_html__( 'The required WordPress plugins are all installed and up to date. Press "Next" to continue the setup wizard.', 'multibank' ),
			'plugins-action-link' => esc_html__( 'Advanced', 'multibank' ),

			'import-header' => esc_html__( 'Import Content', 'multibank' ),
			'import' => esc_html__( 'Let\'s import content to your website, to help you get familiar with the theme.', 'multibank' ),
			'import-action-link' => esc_html__( 'Advanced', 'multibank' ),

			'ready-header' => esc_html__( 'All done. Have fun!', 'multibank' ),

			/* translators: Theme Author */
			'ready%s' => esc_html__( 'Your theme has been all set up. Enjoy your new theme by %s.', 'multibank' ),
			'ready-action-link' => esc_html__( 'Extras', 'multibank' ),
			'ready-big-button' => esc_html__( 'View your website', 'multibank' ),
			'ready-link-1' => sprintf( '<a href="%1$s" target="_blank">%2$s</a>', 'https://cmsmasters.net/', esc_html__( 'Get Theme Support', 'multibank' ) ),
			'ready-link-2' => sprintf( '<a href="%1$s">%2$s</a>', admin_url( 'admin.php?page=go_theme_settings' ), esc_html__( 'Theme Settings', 'multibank' ) ),
		);

		new Config( $config, $strings );

		new Filters();
	}

}
