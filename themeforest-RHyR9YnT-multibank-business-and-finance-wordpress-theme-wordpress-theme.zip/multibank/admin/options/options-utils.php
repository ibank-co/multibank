<?php
namespace MultibankSpace\Admin\Options;

use MultibankSpace\Core\Utils\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Options Utils handler class is responsible for different methods on theme options.
 *
 * @since 1.0.0
 */
class Options_Utils {

	/**
	 * Menu slug.
	 *
	 * @since 1.0.0
	 */
	const MENU_SLUG = 'cmsmasters-options';

	/**
	 * Menu icon.
	 *
	 * @since 1.0.0
	 * @since 1.0.4 Fixed admin menu icon.
	 */
	const MENU_ICON = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="14" viewBox="0 0 342 261" fill="none"><g clip-path="url(#clip0)"><path d="M150.039 181.972L150.037 181.973C135.802 192.154 119.278 197.715 100.4 198.621V181.097C114.57 180.979 126.934 177.281 137.713 170.062C148.282 162.982 156.157 153.577 161.41 141.8H180.637C174.187 158.673 163.959 172.042 150.039 181.972Z" stroke="#e65e2c" stroke-width="4"/><path fill-rule="evenodd" clip-rule="evenodd" d="M101.5 179.1C100.9 179.1 100.4 179.1 99.8 179.1C74.3 179.1 54.9 171.5 41.5 156.3C28.7 141.9 22.3 123.2 22.3 100.4C22.3 77.5 28.7 58.9 41.5 44.5C47.8 37.4 55.6 31.8 64.9 27.8C74.2 23.8 85.8 21.7 99.8 21.7C113.8 21.7 126.1 25.3 136.7 32.4C147.3 39.5 155.1 49.1 160.2 61.1H183.6C177.1 42.6 166.3 27.9 151.3 17.3C135.3 5.7 116.4 0 94.7 0C66.1 0 42.9 9.8 25.2 29.3C8.4 48.1 0 71.7 0 100.3C0 128.9 8.4 152.6 25.2 171.3C43 190.8 66.1 200.6 94.8 200.6C97.1 200.6 99.3 200.5 101.5 200.4V179.1Z" fill="#e65e2c"/><path d="M225.348 159.145L225.336 159.14C215.964 155.431 208.202 150.374 202.114 144.286C196.263 138.435 193.2 130.385 193.2 120C193.2 105.298 198.833 93.3634 210.071 84.0438C218.007 77.5543 230.988 73.6654 245.5 71.7623V73V86.8507C242.486 87.4567 237.361 88.5675 235.698 89.0928L235.678 89.099L235.659 89.1056C229.009 91.3563 223.653 94.1623 219.795 97.4845L219.783 97.4947L219.771 97.5052C215.973 100.881 213.327 104.572 211.993 108.798C210.727 112.805 210.1 117.009 210.1 121.5C210.1 126.439 212.195 130.832 216.205 134.733C220.13 138.552 225.165 141.678 231.442 144.251L231.447 144.253C232.412 144.645 233.799 145.253 235.393 145.953C236.403 146.396 237.497 146.877 238.62 147.361C240.822 148.312 243.144 149.284 245 149.945V166.306C238.8 164.347 230.309 161.147 225.348 159.145ZM206.151 207H188.098C187.949 206.035 187.819 205.077 187.707 204.1H205.74C205.841 205.09 205.982 206.057 206.151 207Z" stroke="#d5418b" stroke-width="4"/><path fill-rule="evenodd" clip-rule="evenodd" d="M284.4 90.8C302.6 95.9 312.6 106.2 314.5 121.8H336.4C335.6 106.7 329.3 94.3 317.4 84.6C304.3 73.6 285.9 68.1 262 68.1C256.5 68.1 251.4 68.4 246.5 68.9V88.9C250.7 88.3 255.4 88 260.4 88C269.9 87.9 277.9 88.9 284.4 90.8ZM321 171.4C314.9 167.4 308 164.2 300.3 161.6C292.5 159 284.6 156.8 276.6 154.8C268.6 152.8 260.6 150.9 252.9 149C250.7 148.5 248.6 147.9 246.5 147.3V168.3C249.5 169.1 252.5 169.8 255.6 170.5C266.7 173 277 175.6 286.6 178.5C296.2 181.3 304.1 184.9 310.5 189.3C316.8 193.7 320 199.6 320 207.2C320 229.4 302.4 240.4 267.2 240.4C250.3 240.4 236.8 237.5 226.6 231.6C214.9 224.8 208.6 214.9 207.9 202.1H185.7C187.4 220.3 194.4 234.3 206.7 244.1C220.5 255.1 240.6 260.6 266.9 260.6C290.2 260.6 308.4 256 321.6 246.7C334.8 237.4 341.3 224 341.3 206.4C341.2 191.6 334.5 179.9 321 171.4Z" fill="#d5418b"/><path fill-rule="evenodd" clip-rule="evenodd" d="M101.8 199.7V199H80.5V199.7H101.8ZM263.4 38.3H238.7L172.5 127.5L105.2 38.3H80.5V199H101.8V70.7L172.5 160.2L242.1 70.7V226.3L247.5 227.5C252.8 228.3 258.4 228.7 263.5 228.8L263.4 38.3Z" fill="#30aacf"/></g><defs><clipPath id="clip0"><rect width="341.2" height="260.6" fill="white"/></clipPath></defs></svg>';

	/**
	 * Pages.
	 *
	 * @since 1.0.0
	 */
	public static $pages = array(
		'demos',
		'license',
		'image-sizes',
		// 'example',
	);

	/**
	 * Main page.
	 *
	 * @since 1.0.0
	 */
	public static $main_page = 'demos';

	/**
	 * Get field value.
	 *
	 * @since 1.0.0
	 *
	 * @param string $id Field id.
	 * @param string $sub_id Field sub id.
	 * @param mixed $std Field std property.
	 *
	 * @return mixed Field value.
	 */
	public static function get_field_value( $id, $sub_id = '', $std = '' ) {
		$options = Utils::get_theme_options();

		if (
			! isset( $options[ $id ] ) ||
			( is_array( $std ) && ! is_array( $options[ $id ] ) )
		) {
			$value = $std;
		} else {
			$value = $options[ $id ];

			if ( '' !== $sub_id ) {
				if ( ! isset( $value[ $sub_id ] ) ) {
					$value = $std;
				} else {
					$value = $value[ $sub_id ];
				}
			}
		}

		return $value;
	}

	/**
	 * Check validate value.
	 *
	 * @since 1.0.0
	 *
	 * @param string $id Field id.
	 * @param string $sub_id Field sub id.
	 * @param mixed $input Field input data.
	 * @param array $args Field args.
	 *
	 * @return mixed Field value.
	 */
	public static function check_validate_input( $id = '', $sub_id = '', $input = array(), $args = array() ) {
		if (
			( '' === $sub_id && ! isset( $input[ $id ] ) ) ||
			( '' !== $sub_id && ! isset( $input[ $id ][ $sub_id ] ) )
		) {
			return '0';
		}

		if ( '' !== $sub_id ) {
			$input_val = $input[ $id ][ $sub_id ];
		} else {
			$input_val = $input[ $id ];
		}

		if ( true === $args['not_empty'] ) {
			if (
				is_array( $args['std'] ) &&
				(
					! is_array( $input_val ) ||
					( is_array( $input_val ) && empty( $input_val ) )
				)
			) {
				$input_val = $args['std'];
			} elseif ( ! is_array( $args['std'] ) && '' === $input_val ) {
				$input_val = $args['std'];
			}
		}

		return $input_val;
	}

	/**
	 * Get field label.
	 *
	 * @since 1.0.0
	 *
	 * @param string $label Field label.
	 * @param string $id Field id.
	 *
	 * @return string Field label HTML.
	 */
	public static function get_field_label( $label = '', $id = '' ) {
		$label = ( '' !== $label ? '<label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label>' : '' );

		return $label;
	}

	/**
	 * Get field description.
	 *
	 * @since 1.0.0
	 *
	 * @param string $desc Field description.
	 *
	 * @return string Field description HTML.
	 */
	public static function get_field_desc( $desc = '' ) {
		$desc = ( '' !== $desc ? '<span class="description">' . $desc . '</span>' : '' );

		return $desc;
	}

	/**
	 * Get field postfix.
	 *
	 * @since 1.0.0
	 *
	 * @param string $desc Field postfix.
	 *
	 * @return string Field postfix HTML.
	 */
	public static function get_field_postfix( $postfix = '' ) {
		$postfix = ( '' !== $postfix ? '<span class="cmsmasters-options-field-postfix">' . $postfix . '</span>' : '' );

		return $postfix;
	}

	/**
	 * Get options message content.
	 *
	 * @since 1.0.0
	 *
	 * @param string $content Message content.
	 * @param string $class Message class.
	 * @param string $option Option id.
	 *
	 * @return string Message content.
	 */
	public static function get_message_content( $content, $class, $option = '' ) {
		$error_option = '';
		$error_link = '';

		if ( '' !== $option ) {
			$error_option = ' data-option="' . esc_attr( $option ) . '"';
			$error_link = '<a href="#' . esc_attr( $option ) . '">' . esc_html__( 'Field error', 'multibank' ) . '</a>. ';
		}

		return '<div class="notice cmsmasters-options-notice ' . $class . '"' . $error_option . '>' .
			'<p>' . $error_link . $content . '</p>' .
		'</div>';
	}

	/**
	 * Get current theme options admin page.
	 *
	 * @since 1.0.0
	 */
	public static function get_admin_page() {
		if ( Utils::is_ajax() ) {
			if ( isset( $_POST['action'] ) ) {
				switch ( $_POST['action'] ) {
					case 'cmsmasters_activate_license':
					case 'cmsmasters_deactivate_license':
						return 'license';

						break;
					case 'cmsmasters_apply_demo':
						return 'demos';

						break;
				}
			}
		}

		global $pagenow;

		$cur_page = ( isset( $_GET['page'] ) ) ? trim( $_GET['page'] ) : '';

		if ( 'options.php' === $pagenow && isset( $_POST['_wp_http_referer'] ) ) {
			$parts = explode( 'page=', $_POST['_wp_http_referer'] );

			if ( isset( $parts[1] ) ) {
				$page = $parts[1];
				$t = strpos( $page, '&' );

				if ( false !== $t ) {
					$page = substr( $parts[1], 0, $t );
				}

				$cur_page = trim( $page );
			} else {
				$cur_page = '';
			}
		}

		if ( '' === $cur_page && false === strpos( $cur_page, self::MENU_SLUG ) ) {
			return '';
		}

		$out = '';

		if ( self::MENU_SLUG === $cur_page ) {
			$out = self::$main_page;
		} else {
			$out = substr( $cur_page, strlen( self::MENU_SLUG ) + 1 );
		}

		return $out;
	}

}
