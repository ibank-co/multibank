<?php
namespace MultibankSpace\Admin\Upgrader;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Upgrader.
 *
 * Main class for upgrader.
 *
 * @since 1.0.0
 */
class Upgrader_Utils {

	/**
	 * Get current version from DB.
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public static function get_current_version() {
		return get_option( 'cmsmasters_multibank_version', '1.0.0' );
	}

	/**
	 * Get current major version.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $version Version string or false to get current version.
	 *
	 * @return string
	 */
	public static function get_major_version( $version = false ) {
		if ( ! $version ) {
			$version = self::get_current_version();
		}

		return substr( $version, 0, strrpos( $version, '.' ) );
	}

	/**
	 * Get current minor version.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $version Version string or false to get current version.
	 *
	 * @return string
	 */
	public static function get_minor_version( $version = false ) {
		if ( ! $version ) {
			$version = self::get_current_version();
		}

		return substr( $version, strrpos( $version, '.' ) + 1 );
	}

}
