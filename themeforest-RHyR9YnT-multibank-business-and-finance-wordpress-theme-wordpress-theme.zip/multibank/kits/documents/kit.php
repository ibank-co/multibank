<?php
namespace MultibankSpace\Kits\Documents;

use MultibankSpace\Kits\Module as KitsModule;
use MultibankSpace\Kits\Settings\Base\Base_Section;
use MultibankSpace\Kits\Settings\Base\Settings_Tab_Base;

use Elementor\Core\Kits\Documents\Kit as BaseKit;
use Elementor\Plugin;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


/**
 * Theme style class.
 *
 * Adds settings for theme style.
 *
 * @since 1.0.0
 */
class Kit extends BaseKit {

	/**
	 * Addon kit document settings tabs.
	 *
	 * @since 1.0.0
	 *
	 * @var array
	 */
	private $settings = array();

	/**
	 * Addon kit document settings sections.
	 *
	 * @since 1.0.0
	 *
	 * @var array
	 */
	private $sections = array();

	/**
	 * Addon kit document class constructor.
	 *
	 * Initializing the Addon kit document initial file class.
	 *
	 * @since 1.0.0
	 *
	 * @param array $data Document data.
	 */
	public function __construct( $data = array() ) {
		parent::__construct( $data );

		$this->register_sections();
		$this->init_settings_tabs();

		$this->init_filters();
	}

	/**
	 * Change css wrapper selector for kit selectors.
	 *
	 * @since 1.0.0
	 */
	public function get_css_wrapper_selector() {
		return ':root';
	}

	/**
	 * Register sections.
	 *
	 * Register Addon kit document settings sections.
	 *
	 * @since 1.0.0
	 */
	private function register_sections() {
		$locations = get_option( 'cmsmasters_elementor_documents_locations', array() );

		$hide_header = false;
		$hide_archive = false;
		$hide_search = false;
		$hide_single = false;
		$hide_footer = false;

		foreach ( $locations as $key => $templates ) {
			if ( 'cmsmasters_header' === $key ) {
				$hide_header = $this->check_sitewide_location( $templates, 'include/general' );
			}

			if ( 'cmsmasters_archive' === $key ) {
				$hide_archive = $this->check_sitewide_location( $templates, 'include/archive' );

				$hide_search = $this->check_sitewide_location( $templates, 'include/archive/search' );
			}

			if ( 'cmsmasters_singular' === $key ) {
				$hide_single = $this->check_sitewide_location( $templates, 'include/singular' );
			}

			if ( 'cmsmasters_footer' === $key ) {
				$hide_footer = $this->check_sitewide_location( $templates, 'include/general' );
			}
		}

		$this->sections = array(
			'general',
			'elements',
		);

		if ( false === $hide_header ) {
			$this->sections = array_merge( $this->sections, array(
				'header-top',
				'header-mid',
				'header-bot',
				'heading',
			) );
		}

		$this->sections[] = 'main';

		if ( false === $hide_archive ) {
			$this->sections[] = 'archive';
		}

		if ( false === $hide_search ) {
			$this->sections[] = 'search';
		}

		if ( false === $hide_single ) {
			$this->sections[] = 'single';
		}

		$this->sections[] = 'sidebar-widgets';

		if ( false === $hide_footer ) {
			$this->sections = array_merge( $this->sections, array(
				'footer-widgets',
				'footer',
			) );
		}
	}

	/**
	 * Check sitewide location.
	 *
	 * @since 1.0.0
	 *
	 * @param array $templates Templates.
	 * @param string $sitewide_location Sitewide location.
	 *
	 * @return bool
	 */
	public function check_sitewide_location( $templates = array(), $sitewide_location = 'include/general' ) {
		$result = false;

		foreach ( $templates as $template_id => $template_args ) {
			if ( in_array( $sitewide_location, $template_args, true ) ) {
				$result = true;

				foreach ( $template_args as $template_location ) {
					if ( false !== strpos( $template_location, 'exclude/' ) ) {
						$result = false;
					}
				}
			}
		}

		return $result;
	}

	/**
	 * Init settings tabs.
	 *
	 * Initialize Addon kit document settings tabs toggles.
	 *
	 * @since 1.0.0
	 */
	protected function init_settings_tabs() {
		foreach ( $this->sections as $section ) {
			$name = str_replace( '-', '', ucwords( $section, '-' ) );
			$instance = KitsModule::KIT_NAMESPACE . "\\Settings\\{$name}\\Section";

			if ( ! class_exists( $instance ) ) {
				continue;
			}

			$this->add_settings_tab( $section, $instance );
		}
	}

	/**
	 * Add settings tab.
	 *
	 * Add new Addon kit document settings tab toggles.
	 *
	 * @since 1.0.0
	 *
	 * @param string $id Addon kit document tab id.
	 * @param Base_Section $instance Addon kit document tab class instance.
	 */
	public function add_settings_tab( $id, $instance ) {
		$name = "cmsmasters-theme-{$id}";

		if ( ! isset( $this->settings[ $name ] ) ) {
			$this->settings[ $name ] = array();
		} elseif ( isset( $this->settings[ $name ]['tab'] ) ) {
			return;
		}

		/** @var Base_Section $section */
		$section = new $instance();

		$this->settings[ $name ]['tab'] = $section;
		$this->settings[ $name ]['toggles'] = array();

		foreach ( $section->get_toggles_config() as $toggle_id => $toggle_instance ) {
			$this->settings[ $name ]['toggles'][ $toggle_id ] = new $toggle_instance( $this, $name );
		}
	}

	/**
	 * Save settings tab.
	 *
	 * Save Addon kit document settings tab toggles controls.
	 *
	 * @since 1.0.0
	 *
	 * @param array $data Kit document data.
	 *
	 * @return array Addon kit document controls data.
	 */
	public function save( $data ) {
		$saved = parent::save( $data );

		if ( ! $saved ) {
			return $saved;
		}

		foreach ( $this->settings as $settings_tab ) {
			if ( empty( $settings_tab ) ) {
				continue;
			}

			/** @var Settings_Tab_Base $setting_tab */
			$toggles = $settings_tab['toggles'];

			foreach ( $toggles as $toggle ) {
				$toggle->on_save( $data );
			}
		}

		return $saved;
	}

	/**
	 * Register controls.
	 *
	 * Register Addon kit document settings tab toggle controls.
	 *
	 * @since 1.0.0
	 */
	protected function register_controls() {
		/**
		 * Before register Elementor kit controls section.
		 *
		 * Fires before default Elementor kit document controls
		 * section are registered.
		 *
		 * @since 1.0.0
		 *
		 * @param Document $this Addon kit document.
		 */
		do_action( 'cmsmasters_elementor/documents/kit/before_register_elementor_kit_controls', $this );

		parent::register_controls();

		/**
		 * Before register Addon kit control sections.
		 *
		 * Fires before default Elementor kit document Addon
		 * control sections are registered.
		 *
		 * @since 1.0.0
		 *
		 * @param Document $this Addon kit document.
		 */
		do_action( 'cmsmasters_elementor/documents/kit/before_register_addon_kit_controls', $this );

		$is_edit_mode = Plugin::$instance->editor->is_edit_mode();

		if ( ! $is_edit_mode ) {
			// In the Front End, the Kit is initialized before CSS is generated, so we always duplicate controls in
			// the kit.
			$initial_responsive_controls_duplication_mode = Plugin::$instance->breakpoints->get_responsive_control_duplication_mode();

			Plugin::$instance->breakpoints->set_responsive_control_duplication_mode( 'on' );
		}

		foreach ( $this->settings as $settings_tab ) {
			if ( empty( $settings_tab ) ) {
				continue;
			}

			/** @var Settings_Tab_Base $setting_tab */
			$toggles = $settings_tab['toggles'];

			foreach ( $toggles as $toggle ) {
				$toggle->register_controls();
			}
		}

		if ( ! $is_edit_mode ) {
			Plugin::$instance->breakpoints->set_responsive_control_duplication_mode( $initial_responsive_controls_duplication_mode );
		}

		/**
		 * After register Addon kit control sections.
		 *
		 * Fires after default Elementor kit document Addon kit
		 * control sections are registered.
		 *
		 * @since 1.0.0
		 *
		 * @param Document $this Addon kit document.
		 */
		do_action( 'cmsmasters_elementor/documents/kit/after_register_addon_kit_controls', $this );
	}

	/**
	 * Get initial config.
	 *
	 * Retrieve Elementor editor initial config.
	 *
	 * @since 1.0.0
	 */
	protected function get_initial_config() {
		$config = parent::get_initial_config();

		foreach ( $this->settings as $setting ) {
			/** @var Base_Section $setting_tab */
			$setting_tab = $setting['tab'];

			$id = $setting_tab::get_id();

			$config['tabs'][ $id ] = array(
				'title' => $setting_tab::get_title(),
				'icon' => $setting_tab::get_icon(),
				'group' => $setting_tab::get_group(),
				'helpUrl' => $setting_tab::get_help_url(),
				'additionalContent' => $setting_tab->get_additional_content(),
			);
		}

		return $config;
	}

	/**
	 * Add filters initialization.
	 *
	 * Register filters for the Addon kit document.
	 *
	 * @since 1.0.0
	 */
	protected function init_filters() {
		// Editor
		add_filter( 'elementor/editor/localize_settings', array( $this, 'localize_settings' ) );
	}

	/**
	 * Localize settings.
	 *
	 * Add new localized settings for the kit document.
	 *
	 * Fired by `elementor/editor/localize_settings` Elementor filter.
	 *
	 * @since 1.0.0
	 *
	 * @param array $settings Localized settings.
	 *
	 * @return array Localized settings.
	 */
	public function localize_settings( $settings ) {
		$settings = array_replace_recursive( $settings, array(
			'i18n' => array(
				'cmsmasters_theme' => esc_html__( 'Theme Settings', 'multibank' ),
				'design_system' => esc_html__( 'Design System', 'multibank' ),
				'theme_style' => esc_html__( 'Theme Style', 'multibank' ),
				'settings' => esc_html__( 'Settings', 'multibank' ),
				'additional_settings' => esc_html__( 'Additional Settings', 'multibank' ),
			),
		) );

		return $settings;
	}

}
