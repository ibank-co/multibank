<?php
namespace MultibankSpace\Kits\Settings\Footer;

use MultibankSpace\Kits\Settings\Base\Base_Section;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


/**
 * Footer section.
 *
 * @since 1.0.0
 */
class Section extends Base_Section {

	/**
	 * Get name.
	 *
	 * Retrieve the section name.
	 *
	 * @since 1.0.0
	 */
	public static function get_name() {
		return 'footer';
	}

	/**
	 * Get title.
	 *
	 * Retrieve the section title.
	 *
	 * @since 1.0.0
	 */
	public static function get_title() {
		return esc_html__( 'Footer', 'multibank' );
	}

	/**
	 * Get icon.
	 *
	 * Retrieve the section icon.
	 *
	 * @since 1.0.0
	 */
	public static function get_icon() {
		return 'eicon-footer';
	}

	/**
	 * Get toggles.
	 *
	 * Retrieve the section toggles.
	 *
	 * @since 1.0.0
	 */
	public static function get_toggles() {
		return array(
			'footer',
			'copyright',
			'nav',
			'social',
			'info',
			'logo',
			'html',
		);
	}

}
