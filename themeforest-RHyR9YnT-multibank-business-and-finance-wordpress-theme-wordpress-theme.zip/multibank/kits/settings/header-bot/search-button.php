<?php
namespace MultibankSpace\Kits\Settings\HeaderBot;

use MultibankSpace\Kits\Settings\Base\Settings_Tab_Base;

use Elementor\Controls_Manager;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


/**
 * Header Bot Search Button settings.
 *
 * @since 1.0.0
 */
class Search_Button extends Settings_Tab_Base {

	/**
	 * Get toggle name.
	 *
	 * Retrieve the toggle name.
	 *
	 * @since 1.0.0
	 *
	 * @return string Toggle name.
	 */
	public static function get_toggle_name() {
		return 'header_bot_search_button';
	}

	/**
	 * Get title.
	 *
	 * Retrieve the toggle title.
	 *
	 * @since 1.0.0
	 */
	public function get_title() {
		return esc_html__( 'Search Button', 'multibank' );
	}

	/**
	 * Get control ID prefix.
	 *
	 * Retrieve the control ID prefix.
	 *
	 * @return string Control ID prefix.
	 */
	protected static function get_control_id_prefix() {
		return parent::get_control_id_prefix() . '_header_bot';
	}

	/**
	 * Get toggle conditions.
	 *
	 * Retrieve the settings toggle conditions.
	 *
	 * @since 1.0.0
	 *
	 * @return array Toggle conditions.
	 */
	protected function get_toggle_conditions() {
		return array(
			'condition' => array(
				$this->get_control_id_parameter( '', 'visibility' ) => 'yes',
				$this->get_control_id_parameter( '', 'type' ) => 'wide',
				$this->get_control_id_parameter( '', 'add_content_elements' ) => 'search_button',
			),
		);
	}

	/**
	* Register toggle controls.
	*
	* Registers the controls of the kit settings tab toggle.
	*
	* @since 1.0.0
	*/
	protected function register_toggle_controls() {
		$this->add_controls_group( 'search_button', self::CONTROLS_ICON, array(
			'states' => array(
				'normal' => esc_html__( 'Normal', 'multibank' ),
				'hover' => esc_html__( 'Hover', 'multibank' ),
			),
			'icon_states' => 'out',
		) );
	}

}
