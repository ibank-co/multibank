<?php
namespace MultibankSpace\Kits\Settings\HeaderMid;

use MultibankSpace\Kits\Settings\Base\Base_Section;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


/**
 * Header Mid section.
 *
 * @since 1.0.0
 */
class Section extends Base_Section {

	/**
	 * Get name.
	 *
	 * Retrieve the section name.
	 *
	 * @since 1.0.0
	 */
	public static function get_name() {
		return 'header-mid';
	}

	/**
	 * Get title.
	 *
	 * Retrieve the section title.
	 *
	 * @since 1.0.0
	 */
	public static function get_title() {
		return esc_html__( 'Header Middle', 'multibank' );
	}

	/**
	 * Get icon.
	 *
	 * Retrieve the section icon.
	 *
	 * @since 1.0.0
	 */
	public static function get_icon() {
		return 'eicon-header';
	}

	/**
	 * Get toggles.
	 *
	 * Retrieve the section toggles.
	 *
	 * @since 1.0.0
	 */
	public static function get_toggles() {
		return array(
			'header-mid',
			'info',
			'html',
			'social',
			'button',
			'search-button',
			'nav-title-item',
			'nav-dropdown-container',
			'nav-dropdown-item',
			'nav-burger-button',
			'nav-burger-container',
			'nav-burger-title-item',
			'nav-burger-dropdown-item',
		);
	}

}
