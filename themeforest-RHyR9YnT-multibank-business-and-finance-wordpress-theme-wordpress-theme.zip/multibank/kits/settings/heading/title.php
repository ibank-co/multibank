<?php
namespace MultibankSpace\Kits\Settings\Heading;

use MultibankSpace\Kits\Settings\Base\Settings_Tab_Base;

use Elementor\Controls_Manager;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


/**
 * Heading Title settings.
 *
 * @since 1.0.0
 */
class Title extends Settings_Tab_Base {

	/**
	 * Get toggle name.
	 *
	 * Retrieve the toggle name.
	 *
	 * @since 1.0.0
	 *
	 * @return string Toggle name.
	 */
	public static function get_toggle_name() {
		return 'heading_title';
	}

	/**
	 * Get title.
	 *
	 * Retrieve the toggle title.
	 *
	 * @since 1.0.0
	 */
	public function get_title() {
		return esc_html__( 'Title', 'multibank' );
	}

	/**
	 * Get control ID prefix.
	 *
	 * Retrieve the control ID prefix.
	 *
	 * @return string Control ID prefix.
	 */
	protected static function get_control_id_prefix() {
		$toggle_name = self::get_toggle_name();

		return parent::get_control_id_prefix() . "_{$toggle_name}";
	}

	/**
	* Register toggle controls.
	*
	* Registers the controls of the kit settings tab toggle.
	*
	* @since 1.0.0
	*/
	protected function register_toggle_controls() {
		$this->add_var_group_control( '', self::VAR_TYPOGRAPHY );

		$this->add_control(
			'color',
			array(
				'label' => esc_html__( 'Color', 'multibank' ),
				'type' => Controls_Manager::COLOR,
				'dynamic' => array(),
				'selectors' => array(
					':root' => '--' . $this->get_control_prefix_parameter( '', 'color' ) . ': {{VALUE}};',
				),
			)
		);
	}

}
