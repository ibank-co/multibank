<?php
namespace MultibankSpace\Kits\Settings\Search;

use MultibankSpace\Kits\Settings\Base\Base_Section;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


/**
 * Search section.
 *
 * @since 1.0.0
 */
class Section extends Base_Section {

	/**
	 * Get name.
	 *
	 * Retrieve the section name.
	 *
	 * @since 1.0.0
	 */
	public static function get_name() {
		return 'search';
	}

	/**
	 * Get title.
	 *
	 * Retrieve the section title.
	 *
	 * @since 1.0.0
	 */
	public static function get_title() {
		return esc_html__( 'Search', 'multibank' );
	}

	/**
	 * Get icon.
	 *
	 * Retrieve the section icon.
	 *
	 * @since 1.0.0
	 */
	public static function get_icon() {
		return 'eicon-search-results';
	}

	/**
	 * Get toggles.
	 *
	 * Retrieve the section toggles.
	 *
	 * @since 1.0.0
	 */
	public static function get_toggles() {
		return array(
			'search',
			'post',
			'media',
			'title',
			'content',
			'meta_first',
			'meta_second',
			'more',
			'pagination',
		);
	}

}
