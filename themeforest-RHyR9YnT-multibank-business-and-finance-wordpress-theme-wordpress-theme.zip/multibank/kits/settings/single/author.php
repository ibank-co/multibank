<?php
namespace MultibankSpace\Kits\Settings\Single;

use MultibankSpace\Kits\Settings\Base\Settings_Tab_Base;

use Elementor\Controls_Manager;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


/**
 * Single Author settings.
 *
 * @since 1.0.0
 */
class Author extends Settings_Tab_Base {

	/**
	 * Get toggle name.
	 *
	 * Retrieve the toggle name.
	 *
	 * @since 1.0.0
	 *
	 * @return string Toggle name.
	 */
	public static function get_toggle_name() {
		return 'single_author';
	}

	/**
	 * Get title.
	 *
	 * Retrieve the toggle title.
	 *
	 * @since 1.0.0
	 */
	public function get_title() {
		return esc_html__( 'Author Box', 'multibank' );
	}

	/**
	 * Get control ID prefix.
	 *
	 * Retrieve the control ID prefix.
	 *
	 * @return string Control ID prefix.
	 */
	protected static function get_control_id_prefix() {
		$toggle_name = self::get_toggle_name();

		return parent::get_control_id_prefix() . '_single';
	}

	/**
	 * Get toggle conditions.
	 *
	 * Retrieve the settings toggle conditions.
	 *
	 * @since 1.0.0
	 *
	 * @return array Toggle conditions.
	 */
	protected function get_toggle_conditions() {
		return array(
			'condition' => array(
				$this->get_control_id_parameter( '', 'blocks' ) => 'author',
			),
		);
	}

	/**
	* Register toggle controls.
	*
	* Registers the controls of the kit settings tab toggle.
	*
	* @since 1.0.0
	*/
	protected function register_toggle_controls() {
		$this->add_control(
			'author_title_text',
			array(
				'label' => esc_html__( 'Title', 'multibank' ),
				'label_block' => false,
				'description' => esc_html__( 'This setting will be applied after save and reload.', 'multibank' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'About Author', 'multibank' ),
			)
		);

		$this->add_controls_group( 'author_box', self::CONTROLS_CONTAINER_BOX, array(
			'excludes' => array(
				'alignment',
				'bg_color',
				'box_shadow',
			),
		) );
	}

}
