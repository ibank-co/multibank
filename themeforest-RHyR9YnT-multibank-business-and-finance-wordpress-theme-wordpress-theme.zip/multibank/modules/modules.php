<?php
namespace MultibankSpace\Modules;

use MultibankSpace\Modules\CSS_Vars;
use MultibankSpace\Modules\Gutenberg;
use MultibankSpace\Modules\Swiper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Theme modules.
 *
 * Main class for theme modules.
 *
 * @since 1.0.0
 */
class Modules {

	/**
	 * Theme modules constructor.
	 *
	 * Run modules for theme.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		new CSS_Vars();

		new Swiper();

		new Gutenberg();
	}

}
