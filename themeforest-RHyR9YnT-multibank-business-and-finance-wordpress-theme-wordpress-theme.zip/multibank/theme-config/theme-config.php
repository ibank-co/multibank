<?php
namespace MultibankSpace\ThemeConfig;

use MultibankSpace\Core\Utils\Utils;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Theme Config.
 *
 * Main class for theme config.
 *
 * @since 1.0.0
 */
class Theme_Config {

	/**
	 * Product key.
	 *
	 * @since 1.0.0
	 */
	const PRODUCT_KEY = '6d756c746962616e6b';

	/**
	 * Import type.
	 *
	 * @since 1.0.3
	 */
	const IMPORT_TYPE = 'demos';

	/**
	 * Major versions.
	 *
	 * @since 1.0.0
	 */
	const MAJOR_VERSIONS = array();

	/**
	 * Default Colors.
	 *
	 * @since 1.0.0
	 */
	const PRIMARY_COLOR_DEFAULT = '#DC1414';
	const SECONDARY_COLOR_DEFAULT = '#191B22';
	const TEXT_COLOR_DEFAULT = '#84858A';
	const ACCENT_COLOR_DEFAULT = '#AE1818';
	const TERTIARY_COLOR_DEFAULT = '#AAABB0';
	const BACKGROUND_COLOR_DEFAULT = '#ffffff';
	const ALTERNATE_COLOR_DEFAULT = '#F5F5F5';
	const BORDER_COLOR_DEFAULT = '#CED0D6';

	/**
	 * Default Typography.
	 *
	 * @since 1.0.0
	 */
	const PRIMARY_TYPOGRAPHY_DEFAULT_FONT_FAMILY = 'Inter';
	const PRIMARY_TYPOGRAPHY_DEFAULT_FONT_WEIGHT = '500';

	const SECONDARY_TYPOGRAPHY_DEFAULT_FONT_FAMILY = 'Inter';
	const SECONDARY_TYPOGRAPHY_DEFAULT_FONT_WEIGHT = '400';

	const TEXT_TYPOGRAPHY_DEFAULT_FONT_FAMILY = 'Inter';
	const TEXT_TYPOGRAPHY_DEFAULT_FONT_SIZE = '17px';
	const TEXT_TYPOGRAPHY_DEFAULT_FONT_WEIGHT = '400';
	const TEXT_TYPOGRAPHY_DEFAULT_TEXT_TRANSFORM = 'none';
	const TEXT_TYPOGRAPHY_DEFAULT_FONT_STYLE = 'normal';
	const TEXT_TYPOGRAPHY_DEFAULT_TEXT_DECORATION = 'none';
	const TEXT_TYPOGRAPHY_DEFAULT_LINE_HEIGHT = '1.65em';
	const TEXT_TYPOGRAPHY_DEFAULT_LETTER_SPACING = '0';

	const ACCENT_TYPOGRAPHY_DEFAULT_FONT_FAMILY = 'Inter';
	const ACCENT_TYPOGRAPHY_DEFAULT_FONT_SIZE = '15px';
	const ACCENT_TYPOGRAPHY_DEFAULT_FONT_WEIGHT = '400';
	const ACCENT_TYPOGRAPHY_DEFAULT_TEXT_TRANSFORM = 'none';
	const ACCENT_TYPOGRAPHY_DEFAULT_FONT_STYLE = 'normal';
	const ACCENT_TYPOGRAPHY_DEFAULT_TEXT_DECORATION = 'none';
	const ACCENT_TYPOGRAPHY_DEFAULT_LINE_HEIGHT = '1.6em';
	const ACCENT_TYPOGRAPHY_DEFAULT_LETTER_SPACING = '0';

	const TERTIARY_TYPOGRAPHY_DEFAULT_FONT_FAMILY = 'Inter';
	const TERTIARY_TYPOGRAPHY_DEFAULT_FONT_SIZE = '15px';
	const TERTIARY_TYPOGRAPHY_DEFAULT_FONT_WEIGHT = '400';
	const TERTIARY_TYPOGRAPHY_DEFAULT_TEXT_TRANSFORM = 'none';
	const TERTIARY_TYPOGRAPHY_DEFAULT_FONT_STYLE = 'normal';
	const TERTIARY_TYPOGRAPHY_DEFAULT_TEXT_DECORATION = 'none';
	const TERTIARY_TYPOGRAPHY_DEFAULT_LINE_HEIGHT = '1.6em';
	const TERTIARY_TYPOGRAPHY_DEFAULT_LETTER_SPACING = '0';

	const META_TYPOGRAPHY_DEFAULT_FONT_FAMILY = 'Inter';
	const META_TYPOGRAPHY_DEFAULT_FONT_SIZE = '14px';
	const META_TYPOGRAPHY_DEFAULT_FONT_WEIGHT = '400';
	const META_TYPOGRAPHY_DEFAULT_TEXT_TRANSFORM = 'none';
	const META_TYPOGRAPHY_DEFAULT_FONT_STYLE = 'normal';
	const META_TYPOGRAPHY_DEFAULT_TEXT_DECORATION = 'none';
	const META_TYPOGRAPHY_DEFAULT_LINE_HEIGHT = '1.6em';
	const META_TYPOGRAPHY_DEFAULT_LETTER_SPACING = '0';

	const TAXONOMY_TYPOGRAPHY_DEFAULT_FONT_FAMILY = 'Inter';
	const TAXONOMY_TYPOGRAPHY_DEFAULT_FONT_SIZE = '14px';
	const TAXONOMY_TYPOGRAPHY_DEFAULT_FONT_WEIGHT = '500';
	const TAXONOMY_TYPOGRAPHY_DEFAULT_TEXT_TRANSFORM = 'uppercase';
	const TAXONOMY_TYPOGRAPHY_DEFAULT_FONT_STYLE = 'normal';
	const TAXONOMY_TYPOGRAPHY_DEFAULT_TEXT_DECORATION = 'none';
	const TAXONOMY_TYPOGRAPHY_DEFAULT_LINE_HEIGHT = '1.6em';
	const TAXONOMY_TYPOGRAPHY_DEFAULT_LETTER_SPACING = '1px';

	const SMALL_TYPOGRAPHY_DEFAULT_FONT_FAMILY = 'Inter';
	const SMALL_TYPOGRAPHY_DEFAULT_FONT_SIZE = '14px';
	const SMALL_TYPOGRAPHY_DEFAULT_FONT_WEIGHT = '400';
	const SMALL_TYPOGRAPHY_DEFAULT_TEXT_TRANSFORM = 'none';
	const SMALL_TYPOGRAPHY_DEFAULT_FONT_STYLE = 'normal';
	const SMALL_TYPOGRAPHY_DEFAULT_TEXT_DECORATION = 'none';
	const SMALL_TYPOGRAPHY_DEFAULT_LINE_HEIGHT = '1.6em';
	const SMALL_TYPOGRAPHY_DEFAULT_LETTER_SPACING = '0';

	const H1_TYPOGRAPHY_DEFAULT_FONT_FAMILY = 'Inter';
	const H1_TYPOGRAPHY_DEFAULT_FONT_SIZE = '56px';
	const H1_TYPOGRAPHY_DEFAULT_FONT_WEIGHT = '500';
	const H1_TYPOGRAPHY_DEFAULT_TEXT_TRANSFORM = 'none';
	const H1_TYPOGRAPHY_DEFAULT_FONT_STYLE = 'normal';
	const H1_TYPOGRAPHY_DEFAULT_TEXT_DECORATION = 'none';
	const H1_TYPOGRAPHY_DEFAULT_LINE_HEIGHT = '1.15em';
	const H1_TYPOGRAPHY_DEFAULT_LETTER_SPACING = '-1px';

	const H2_TYPOGRAPHY_DEFAULT_FONT_FAMILY = 'Inter';
	const H2_TYPOGRAPHY_DEFAULT_FONT_SIZE = '44px';
	const H2_TYPOGRAPHY_DEFAULT_FONT_WEIGHT = '500';
	const H2_TYPOGRAPHY_DEFAULT_TEXT_TRANSFORM = 'none';
	const H2_TYPOGRAPHY_DEFAULT_FONT_STYLE = 'normal';
	const H2_TYPOGRAPHY_DEFAULT_TEXT_DECORATION = 'none';
	const H2_TYPOGRAPHY_DEFAULT_LINE_HEIGHT = '1.2em';
	const H2_TYPOGRAPHY_DEFAULT_LETTER_SPACING = '-1px';

	const H3_TYPOGRAPHY_DEFAULT_FONT_FAMILY = 'Inter';
	const H3_TYPOGRAPHY_DEFAULT_FONT_SIZE = '35px';
	const H3_TYPOGRAPHY_DEFAULT_FONT_WEIGHT = '500';
	const H3_TYPOGRAPHY_DEFAULT_TEXT_TRANSFORM = 'none';
	const H3_TYPOGRAPHY_DEFAULT_FONT_STYLE = 'normal';
	const H3_TYPOGRAPHY_DEFAULT_TEXT_DECORATION = 'none';
	const H3_TYPOGRAPHY_DEFAULT_LINE_HEIGHT = '1.25em';
	const H3_TYPOGRAPHY_DEFAULT_LETTER_SPACING = '-1px';

	const H4_TYPOGRAPHY_DEFAULT_FONT_FAMILY = 'Inter';
	const H4_TYPOGRAPHY_DEFAULT_FONT_SIZE = '28px';
	const H4_TYPOGRAPHY_DEFAULT_FONT_WEIGHT = '400';
	const H4_TYPOGRAPHY_DEFAULT_TEXT_TRANSFORM = 'none';
	const H4_TYPOGRAPHY_DEFAULT_FONT_STYLE = 'normal';
	const H4_TYPOGRAPHY_DEFAULT_TEXT_DECORATION = 'none';
	const H4_TYPOGRAPHY_DEFAULT_LINE_HEIGHT = '1.3em';
	const H4_TYPOGRAPHY_DEFAULT_LETTER_SPACING = '-1px';

	const H5_TYPOGRAPHY_DEFAULT_FONT_FAMILY = 'Inter';
	const H5_TYPOGRAPHY_DEFAULT_FONT_SIZE = '22px';
	const H5_TYPOGRAPHY_DEFAULT_FONT_WEIGHT = '400';
	const H5_TYPOGRAPHY_DEFAULT_TEXT_TRANSFORM = 'none';
	const H5_TYPOGRAPHY_DEFAULT_FONT_STYLE = 'normal';
	const H5_TYPOGRAPHY_DEFAULT_TEXT_DECORATION = 'none';
	const H5_TYPOGRAPHY_DEFAULT_LINE_HEIGHT = '1.3em';
	const H5_TYPOGRAPHY_DEFAULT_LETTER_SPACING = '0';

	const H6_TYPOGRAPHY_DEFAULT_FONT_FAMILY = 'Inter';
	const H6_TYPOGRAPHY_DEFAULT_FONT_SIZE = '18px';
	const H6_TYPOGRAPHY_DEFAULT_FONT_WEIGHT = '400';
	const H6_TYPOGRAPHY_DEFAULT_TEXT_TRANSFORM = 'none';
	const H6_TYPOGRAPHY_DEFAULT_FONT_STYLE = 'normal';
	const H6_TYPOGRAPHY_DEFAULT_TEXT_DECORATION = 'none';
	const H6_TYPOGRAPHY_DEFAULT_LINE_HEIGHT = '1.35em';
	const H6_TYPOGRAPHY_DEFAULT_LETTER_SPACING = '0';

	const BUTTON_TYPOGRAPHY_DEFAULT_FONT_FAMILY = 'Inter';
	const BUTTON_TYPOGRAPHY_DEFAULT_FONT_SIZE = '16px';
	const BUTTON_TYPOGRAPHY_DEFAULT_FONT_WEIGHT = '500';
	const BUTTON_TYPOGRAPHY_DEFAULT_TEXT_TRANSFORM = 'none';
	const BUTTON_TYPOGRAPHY_DEFAULT_FONT_STYLE = 'normal';
	const BUTTON_TYPOGRAPHY_DEFAULT_TEXT_DECORATION = 'none';
	const BUTTON_TYPOGRAPHY_DEFAULT_LINE_HEIGHT = '1.4em';
	const BUTTON_TYPOGRAPHY_DEFAULT_LETTER_SPACING = '0';

	const BLOCKQUOTE_TYPOGRAPHY_DEFAULT_FONT_FAMILY = 'Inter';
	const BLOCKQUOTE_TYPOGRAPHY_DEFAULT_FONT_SIZE = '24px';
	const BLOCKQUOTE_TYPOGRAPHY_DEFAULT_FONT_WEIGHT = '400';
	const BLOCKQUOTE_TYPOGRAPHY_DEFAULT_TEXT_TRANSFORM = 'none';
	const BLOCKQUOTE_TYPOGRAPHY_DEFAULT_FONT_STYLE = 'italic';
	const BLOCKQUOTE_TYPOGRAPHY_DEFAULT_TEXT_DECORATION = 'none';
	const BLOCKQUOTE_TYPOGRAPHY_DEFAULT_LINE_HEIGHT = '1.5em';
	const BLOCKQUOTE_TYPOGRAPHY_DEFAULT_LETTER_SPACING = '0';

	/**
	 * Theme_Config constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'after_switch_theme', array( $this, 'after_switch_theme_actions' ) );

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_default_assets' ), 8 );
		add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_default_assets' ), 8 );
	}

	/**
	 * Actions on after switch theme.
	 *
	 * @since 1.0.0
	 */
	public function after_switch_theme_actions() {
		$cpt_support = get_option( 'elementor_cpt_support', array( 'post', 'page', 'e-landing-page' ) );

		if ( is_array( $cpt_support ) ) {
			if ( ! in_array( 'cmsms_service', $cpt_support ) ) {
				$cpt_support[] = 'cmsms_service';
			}
		}

		update_option( 'elementor_cpt_support', $cpt_support );
	}

	/**
	 * Enqueue default assets.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_default_assets() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			wp_enqueue_style(
				'multibank-default-fonts',
				'https://fonts.googleapis.com/css?family=Inter%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic',
				array(),
				'1.0.0',
				'screen'
			);
		}

		if ( '' === Utils::get_active_kit() || ! did_action( 'elementor/loaded' ) ) {
			$default_styles = '.wp-block-widget-area h2.wp-block-heading,
			.widget h2 {
				font-family: var(--cmsmasters-h5-font-family);
				font-weight: var(--cmsmasters-h5-font-weight);
				font-style: var(--cmsmasters-h5-font-style);
				text-transform: var(--cmsmasters-h5-text-transform);
				text-decoration: var(--cmsmasters-h5-text-decoration);
				font-size: var(--cmsmasters-h5-font-size);
				line-height: var(--cmsmasters-h5-line-height);
				letter-spacing: var(--cmsmasters-h5-letter-spacing);
			}

			.wp-block-button .wp-block-button__link {
				border-radius: 50px;
			}

			@media only screen and (max-width: 767px) {
				body {
					--cmsmasters-archive-compact-media-width: 100%;
					--cmsmasters-archive-media-box-margin-right: 0;
					--cmsmasters-archive-media-box-margin-bottom: 40px;
					--cmsmasters-search-compact-media-width: 100%;
					--cmsmasters-search-media-box-margin-right: 0;
					--cmsmasters-search-media-box-margin-bottom: 40px;
				}
			}';

			wp_add_inline_style( 'multibank-default-fonts', $default_styles );
		}
	}

}
