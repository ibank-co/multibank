<?php
namespace MultibankSpace\Woocommerce;

use MultibankSpace\Core\Utils\File_Manager;
use MultibankSpace\TemplateFunctions\General_Elements;
use MultibankSpace\TemplateFunctions\Main_Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Plugin handler class is responsible for woocommerce different methods.
 *
 * @since 1.0.0
 */
class Plugin {

	/**
	 * Plugin constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		if ( ! class_exists( 'woocommerce' ) ) {
			return;
		}

		add_action( 'after_setup_theme', array( $this, 'add_support' ) );

		add_filter( 'cmsmasters_stylesheet_templates_paths_filter', array( $this, 'stylesheet_templates_paths_filter' ) );

		add_filter( 'cmsmasters_singular_id_filter', array( $this, 'filter_singular_id' ) );

		remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
		add_action( 'woocommerce_before_main_content', array( $this, 'wrapper_start' ), 10 );

		remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
		add_action( 'woocommerce_after_main_content', array( $this, 'wrapper_end' ), 10 );

		remove_action( 'woocommerce_after_shop_loop', 'woocommerce_pagination', 10 );
		add_action( 'woocommerce_after_shop_loop', array( $this, 'pagination' ), 10 );

		remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );

		add_filter( 'woocommerce_show_page_title', '__return_false' );

		add_filter( 'cmsmasters_page_title_filter_after', array( $this, 'filter_page_title' ) );

		add_filter( 'woocommerce_enqueue_styles', array( $this, 'enqueue_styles' ) );

		add_filter( 'wc_add_to_cart_message_html', array( $this, 'filter_wc_add_to_cart_message_html' ), 10 );

		add_filter( 'get_product_search_form', array( $this, 'filter_product_search_form' ) );

		add_filter( 'woocommerce_loop_add_to_cart_link', array( $this, 'filter_woocommerce_loop_add_to_cart_link' ), 10, 3 );
	}

	/**
	 * Add support.
	 *
	 * @since 1.0.0
	 */
	public function add_support() {
		// general:
		add_theme_support( 'woocommerce' );

		// Enabling WooCommerce product gallery features (are off by default since WC 3.0.0):
		// zoom:
		add_theme_support( 'wc-product-gallery-zoom' );
		// lightbox:
		add_theme_support( 'wc-product-gallery-lightbox' );
		// swipe:
		add_theme_support( 'wc-product-gallery-slider' );
	}

	/**
	 * Stylesheet templates paths filter.
	 *
	 * @since 1.0.2
	 *
	 * @param array $templates_paths Templates paths.
	 *
	 * @return array Filtered templates paths.
	 */
	public function stylesheet_templates_paths_filter( $templates_paths ) {
		return array_merge( $templates_paths, array(
			File_Manager::get_responsive_css_path() . 'woocommerce.css',
			File_Manager::get_responsive_css_path() . 'woocommerce.min.css',
			File_Manager::get_responsive_css_path() . 'woocommerce-rtl.css',
			File_Manager::get_responsive_css_path() . 'woocommerce-rtl.min.css',
		) );
	}

	/**
	 * Filter singular ID for shop page.
	 *
	 * @since 1.0.0
	 */
	public function filter_singular_id( $id ) {
		if ( is_shop() ) {
			$id = wc_get_page_id( 'shop' );
		}

		return $id;
	}

	/**
	 * Wrapper start HTML.
	 *
	 * @since 1.0.0
	 * @since 1.0.3 Fixed main layout.
	 */
	public function wrapper_start() {
		echo Main_Elements::main_wrapper_start();
	}

	/**
	 * Wrapper end HTML.
	 *
	 * @since 1.0.0
	 * @since 1.0.3 Fixed main layout.
	 */
	public function wrapper_end() {
		echo Main_Elements::main_wrapper_end();
	}

	/**
	 * Pagination HTML.
	 *
	 * @since 1.0.0
	 */
	public function pagination() {
		echo General_Elements::get_pagination( array(
			'parent_class' => 'cmsmasters-archive',
		) );
	}

	/**
	 * Filter page title.
	 *
	 * @since 1.0.0
	 *
	 * @param string title Page Title.
	 *
	 * @return string Page title.
	 */
	public function filter_page_title( $title ) {
		if ( ! is_shop() ) {
			return $title;
		}

		$id = wc_get_page_id( 'shop' );

		return get_the_title( $id );
	}

	/**
	 * Enqueue theme compatibility styles.
	 *
	 * @since 1.0.0
	 *
	 * @param array $styles Array of registered styles.
	 *
	 * @return array
	 */
	public function enqueue_styles( $styles ) {
		unset( $styles['woocommerce-general'] );

		$styles['woocommerce-general'] = array(
			'src'     => File_Manager::get_css_template_assets_url( 'woocommerce', null, 'default', true ),
			'deps'    => '',
			'version' => '1.0.0',
			'media'   => 'all',
			'has_rtl' => false,
		);

		return $styles;
	}

	/**
	 * Filter add to cart message HTML.
	 *
	 * @since 1.0.0
	 *
	 * @param string $message Message HTML.
	 *
	 * @return string Message HTML.
	 */
	public function filter_wc_add_to_cart_message_html( $message ) {
		return '<div class="cmsmasters-wc-add-to-cart-message">' . wp_kses_post( $message ) . '</div>';
	}

	/**
	 * Filter product search form.
	 *
	 * @since 1.0.0
	 *
	 * @return string Search form HTML.
	 */
	public function filter_product_search_form() {
		return General_Elements::get_search_form( 'woocommerce' );
	}

	/**
	 * Filter woocommerce_loop_add_to_cart_link.
	 *
	 * @since 1.0.0
	 *
	 * @return string Search form HTML.
	 */
	public function filter_woocommerce_loop_add_to_cart_link( $link, $product, $args ) {
		return sprintf(
			'<a href="%s" data-quantity="%s" class="%s" %s><span>%s</span></a>',
			esc_url( $product->add_to_cart_url() ),
			esc_attr( isset( $args['quantity'] ) ? $args['quantity'] : 1 ),
			esc_attr( isset( $args['class'] ) ? $args['class'] : 'button' ),
			isset( $args['attributes'] ) ? wc_implode_html_attributes( $args['attributes'] ) : '',
			esc_html( $product->add_to_cart_text() )
		);
	}

}
